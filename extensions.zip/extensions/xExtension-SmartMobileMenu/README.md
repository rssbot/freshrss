# FreshRSS Smart Mobile Menu
Minimizes the required button space and groups buttons

# Screenshot:
![Screenshot](https://rawgit.com/oyox/FreshRSS-extensions/master/xExtension-SmartMobileMenu/screenshot1.png)

![Screenshot](https://rawgit.com/oyox/FreshRSS-extensions/master/xExtension-SmartMobileMenu/screenshot3.png)

![Screenshot](https://rawgit.com/oyox/FreshRSS-extensions/master/xExtension-SmartMobileMenu/screenshot2.png)

![Screenshot](https://rawgit.com/oyox/FreshRSS-extensions/master/xExtension-SmartMobileMenu/screenshot4.png)

# Installation
To use it, upload the *xExtension-SmartMobileMenu* folder in your ./extensions directory and enable it on the extension panel in FreshRSS.