# FreshRSS MobileScrollMenu
Automatically hides the header menu on mobile phones, when scrolling down and shows it when scrolling up.

# Screenshot:
![Screenshot](https://cdn.rawgit.com/oyox/FreshRSS-extensions/5bdd4e05/xExtension-MobileScrollMenu/mobilescrollmenu.gif)

# Installation
To use it, upload the *xExtension-MobileScrollMenu* folder in your ./extensions directory and enable it on the extension panel in FreshRSS.

# Changelog
0.2 
- to prevent menu showup while switching expanded articles I created a "human-scroll recognition"

0.1
- first release