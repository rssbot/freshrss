# FreshRSS FixedNavMenu
Sets the position of the navigation menu to fixed when scrolling down on the desktop version of FreshRSS

# Installation
To use it, upload the *xExtension-FixedNavMenu* folder in your ./extensions directory and enable it on the extension panel in FreshRSS.