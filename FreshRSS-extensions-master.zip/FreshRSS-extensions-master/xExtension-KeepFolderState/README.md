# FreshRSS KeepFolderState
Stores the state of the folders locally and expand them automatically if necessary.

# Installation
To use it, upload the *xExtension-KeepFolderState* folder in your ./extensions directory and enable it on the extension panel in FreshRSS.